==================================================
NMOLABS — OFFICIAL BRAND ASSET PACKAGE
==================================================

Official brand assets for NmoLabs (نمو لابز).

Contents:
- PNG/nmolabs-logo-primary-2750x2750.png: High-resolution (2750x2750) 32-bit truecolor PNG with transparent alpha background.

Brand Guidelines & Usage:
- Do not stretch, compress, or rotate the logo.
- Maintain adequate clear space around the mark.
- Use on clean dark, light, or transparent backdrops.
- Primary Brand Blue: #0F62FE / #4589FF (Dark Mode)
- Secondary Cyan: #0072C3 / #33B1FF
- Accent Emerald: #10B981 / #22D3A0

Website: https://nmolabs.com
Official Brand Center: https://nmolabs.com/brand
